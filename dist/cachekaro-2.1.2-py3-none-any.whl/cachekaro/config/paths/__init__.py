"""
Platform-specific cache path configurations.
"""
